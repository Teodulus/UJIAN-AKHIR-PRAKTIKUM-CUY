<?php $__env->startSection('content'); ?>
<div class="homepage my-5">
    <!-- Judul Utama -->
    <h1 class="text-center text-primary mb-4">Welcome to Glowify!</h1>

    <!-- Bagian Artikel Unggulan -->
    <div class="featured-section container">
        <h2 class="text-secondary text-center mb-3">Featured Articles</h2>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $featuredArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <p class="text-center text-muted">No featured articles available.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelTST\uap\UJIAN-AKHIR-PRAKTIKUM-CUY\glowify_app\resources\views/homepage.blade.php ENDPATH**/ ?>